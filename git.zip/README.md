mod_lotto
=========

A Simple Joomla module for displaying UK Lottery Results. Uses the LottoPredict API to retrieve results, code is kind of messy but as there's not been much interest in the module I've not really found the time to tidy it up!

